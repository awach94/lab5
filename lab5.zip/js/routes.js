angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.akademiaMorskaWGdyni', {
    url: '/page5',
    views: {
      'tab2': {
        templateUrl: 'templates/akademiaMorskaWGdyni.html',
        controller: 'akademiaMorskaWGdyniCtrl'
      }
    }
  })

  .state('tabsController.kontakt', {
    url: '/page6',
    views: {
      'tab2': {
        templateUrl: 'templates/kontakt.html',
        controller: 'kontaktCtrl'
      }
    }
  })

  .state('tabsController.wydziaY', {
    url: '/page7',
    views: {
      'tab2': {
        templateUrl: 'templates/wydziaY.html',
        controller: 'wydziaYCtrl'
      }
    }
  })

  .state('tabsController.quiz', {
    url: '/page8',
    views: {
      'tab2': {
        templateUrl: 'templates/quiz.html',
        controller: 'quizCtrl'
      }
    }
  })

  .state('tabsController.przegraE', {
    url: '/page9',
    views: {
      'tab2': {
        templateUrl: 'templates/przegraE.html',
        controller: 'przegraECtrl'
      }
    }
  })

  .state('tabsController.pytanie1', {
    url: '/page10',
    views: {
      'tab2': {
        templateUrl: 'templates/pytanie1.html',
        controller: 'pytanie1Ctrl'
      }
    }
  })

  .state('tabsController.pytanie2', {
    url: '/page11',
    views: {
      'tab2': {
        templateUrl: 'templates/pytanie2.html',
        controller: 'pytanie2Ctrl'
      }
    }
  })

  .state('tabsController.pytanie3', {
    url: '/page12',
    views: {
      'tab2': {
        templateUrl: 'templates/pytanie3.html',
        controller: 'pytanie3Ctrl'
      }
    }
  })

  .state('tabsController.wygraEs', {
    url: '/page13',
    views: {
      'tab2': {
        templateUrl: 'templates/wygraEs.html',
        controller: 'wygraEsCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/page5')

  

});